#!/bin/bash

gcc -I../include Smarty.c libcAI.so -lm -o Smarty
