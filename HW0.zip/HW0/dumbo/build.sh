#!/bin/bash

gcc -I../include Dumbo.c libcAI.so -o Dumbo
