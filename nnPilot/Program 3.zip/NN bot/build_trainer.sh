#!/bin/bash

gcc mlpPilot.c -lm -o MLPTrain -D TRAINER
